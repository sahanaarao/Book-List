import React from 'react';
import './App.css';

const BookList = () => {
  const books = [
    {
      title: 'Diary of a Wimpy Kid- The Deep End',
      author: 'Jeff Kinney',
      genre: 'Comedy',
  image:'https://www.publishersweekly.com/images/data/ARTICLE_PHOTO/photo/000/071/71912-1.JPG',
    },
    {
      title: 'Diary of a Wimpy Kid- The Last Straw',
      author: 'Jeff Kinney',
      genre: 'Comedy',
      image: 'https://i.pinimg.com/236x/9f/18/c0/9f18c0c9696ffcc430591986f1761f1c--jeff-kinney-wimpy-kid.jpg',
    },
    {
      title: 'Diary of a Wimpy Kid- The Ugly Truth',
      author: 'Jeff Kinney',
      genre: 'Comedy',
      image: 'https://upload.wikimedia.org/wikipedia/en/0/0a/Diary_of_a_Wimpy_Kid_The_Ugly_Truth_book_cover.jpg',
    },
  ];

  return (
    <div className="container">
      <h1 className="title">Book List</h1>
      {books.map((book, index) => (
        <div className="book" key={index}>
          <img className="book-image" src={book.image} alt={book.title} />
          <div className="book-info">
            <h3>{book.title}</h3>
            <p>Author: {book.author}</p>
            <p>Genre: {book.genre}</p>
          </div>
          <hr />
        </div>
      ))}
    </div>
  );
};

export default BookList;
